# mypy: ignore-errors
"""
pygifi — Python port of the R Gifi library.

Multivariate Analysis with Optimal Scaling.

Original R package: Mair, De Leeuw, Groenen (GPL-3.0)
Python port: GPL-3.0-or-later
"""

from pygifi.models.homals import Homals
from pygifi.models.princals import Princals
from pygifi.models.morals import Morals
from pygifi.models.impute import GifiIterativeImputer
from pygifi.utils.coding import make_numeric, encode, decode, categorical_encode, categorical_decode
from pygifi.utils.splines import knots_gifi
from pygifi.core.engine import gifi_transform
from pygifi.utils.datasets import get_dataset
from pygifi.core.cv import cv_morals
from pygifi.utils.isotone import cone_regression
from pygifi.visualization.plot import plot_object_scores, plot_quantifications, plot_biplot

__version__ = "1.0.0"
from typing import List

__all__: List[str] = [
    "Homals",
    "Princals",
    "Morals",
    "GifiIterativeImputer",
    "make_numeric",
    "knots_gifi",
    "gifi_transform",
    "encode",
    "decode",
    "categorical_encode",
    "categorical_decode",
    "get_dataset",
    "cv_morals",
    "cone_regression",
    "plot_object_scores",
    "plot_quantifications",
    "plot_biplot",
    "__version__"]
