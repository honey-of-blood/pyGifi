# mypy: ignore-errors
"""
pygifi._engine — Core ALS engine and transformation routing.

Python port of Gifi/R/gifiEngine.R + Gifi/R/gifiTransform.R
(Mair, De Leeuw, Groenen. GPL-3.0).

Functions
---------
gifi_transform : R gifiTransform — routes to cone_regression by (degree, ordinal)
gifi_engine    : R gifiEngine   — full ALS loop for all Gifi methods
"""

import numpy as np
from pygifi.core.linalg import gs_rc, ls_rc
from pygifi.utils.utilities import center, normalize
from pygifi.utils.isotone import cone_regression
from pygifi.core.structures import make_x_gifi


def gifi_transform(
        data,
        target,
        basis,
        copies,
        degree,
        ordinal,
        ties,
        missing):
    """
    Apply optimal scaling transformation to one variable.

    Python port of R's gifiTransform(data, target, basis, copies, degree, ordinal, ties, missing).

    Routes to cone_regression based on measurement level:
    - degree == -1, not ordinal → subspace ('s'): indicator basis OLS
    - degree == -1, ordinal     → categorical ('c'): monotone on categories
    - degree >= 0, not ordinal  → subspace ('s'): spline/polynomial OLS
    - degree >= 0, ordinal      → Dykstra ('i'):  spline+isotone intersection
    Extra copies (l >= 1) always use subspace ('s').

    Parameters
    ----------
    data    : np.ndarray (n,)
    target  : np.ndarray (n, copies)
    basis   : np.ndarray (n, k)
    copies  : int
    degree  : int
    ordinal : bool
    ties    : str
    missing : str

    Returns
    -------
    np.ndarray (n, copies)
    """
    nobs = len(data)
    h = np.zeros((nobs, copies))

    # First copy: route by (degree, ordinal)
    t0 = target[:, 0]
    if degree == -1:
        if ordinal:
            h[:, 0] = cone_regression(data=data, target=t0, type='c',
                                      ties=ties, missing=missing)
        else:
            h[:, 0] = cone_regression(data=data, target=t0, basis=basis,
                                      type='s', missing=missing)
    else:  # degree >= 0
        if ordinal:
            h[:, 0] = cone_regression(data=data, target=t0, basis=basis,
                                      type='i', ties=ties, missing=missing)
        else:
            h[:, 0] = cone_regression(data=data, target=t0, basis=basis,
                                      type='s', ties=ties, missing=missing)

    # Extra copies: always subspace
    for copy_idx in range(1, copies):
        h[:,
          copy_idx] = cone_regression(data=data,
                                      target=target[:,
                                                    copy_idx],
                                      basis=basis,
                                      type='s',
                                      ties=ties,
                                      missing=missing)

    return h


def gifi_engine(gifi, ndim, itmax=1000, eps=1e-6, verbose=False, init_x=None):
    """
    Alternating Least Squares engine for all Gifi methods.

    Python port of R's gifiEngine(gifi, ndim, itmax, eps, verbose).

    Parameters
    ----------
    gifi    : list of lists — from make_gifi()
    ndim    : int — number of dimensions
    itmax   : int — maximum ALS iterations
    eps     : float — convergence threshold on loss change
    verbose : bool — print iteration info
    init_x  : np.ndarray (nobs, ndim), optional
        Custom initial random matrix. If provided, this is used directly
        instead of generating one with np.random.seed(123). To get exact
        parity with R, generate this matrix in R with:
            set.seed(123)
            x <- matrix(rnorm(nobs * ndim), nobs, ndim)
        and pass to Python. If None (default), uses NumPy's RNG with seed 123.

    Returns
    -------
    dict with keys: f, ntel, x, xGifi
    """
    # Get nobs from first variable of first set
    nobs = len(gifi[0][0]['data'])
    len(gifi)
    nvars = sum(len(s) for s in gifi)

    if nvars < 2:
        raise ValueError(
            "gifi_engine requires at least two variables to perform multivariate analysis, "
            f"but only {nvars} were provided.")

    # --- Initialization ---
    if init_x is not None:
        # User-provided initial matrix (e.g., from R for exact parity)
        x = np.asarray(init_x, dtype=float)
        if x.shape != (nobs, ndim):
            raise ValueError(
                f"init_x must have shape ({nobs}, {ndim}), got {x.shape}")
    else:
        # Default: NumPy RNG with seed 123 (mirrors R's set.seed(123))
        np.random.seed(123)
        x = np.random.randn(nobs, ndim)

    x = gs_rc(center(x))['q']

    xGifi = make_x_gifi(gifi, x)

    # Compute initial loss fold
    fold = 0.0
    asets = 0
    for i, gifi_set in enumerate(gifi):
        x_set = xGifi[i]
        ha = np.zeros((nobs, ndim))
        active_count = 0
        for j, gv in enumerate(gifi_set):
            if gv['active']:
                active_count += 1
                ha += x_set[j]['scores']
        if active_count > 0:
            asets += 1
            fold += np.sum((x - ha) ** 2)
    fold /= (asets * ndim)

    # --- ALS loop ---
    itel = 1
    while True:
        xz = np.zeros((nobs, ndim))
        fnew = 0.0
        fmid = 0.0

        for i, gifi_set in enumerate(gifi):
            x_set = xGifi[i]

            # Stack transforms of active variables: hh (nobs,
            # sum_active_copies)
            hh_parts = []
            active_count = 0
            for j, gv in enumerate(gifi_set):
                if gv['active']:
                    active_count += 1
                    hh_parts.append(x_set[j]['transform'])
            if active_count == 0:
                continue

            hh = np.hstack(hh_parts)               # (nobs, sum_copies)

            # OLS regression of hh onto x
            lf = ls_rc(hh, x)
            aa = lf['solution']                     # (sum_copies, ndim)
            rs = lf['residuals']                    # (nobs, ndim)

            # Step-size scaling: kappa = max eigenvalue of aa.T @ aa
            eigvals = np.linalg.eigh(aa.T @ aa)[0]
            kappa = float(eigvals.max())

            fmid += np.sum(rs ** 2)

            # ALS target update: target = hh + rs @ aa.T / kappa
            target = hh + rs @ aa.T / kappa         # (nobs, sum_copies)

            # Update each variable's transform
            hh_new_parts = []
            scopies = 0
            for j, gv in enumerate(gifi_set):
                jcopies = x_set[j]['transform'].shape[1]
                ja = aa[scopies:scopies + jcopies, :]        # (copies, ndim)
                # (nobs, copies)
                jtarget = target[:, scopies:scopies + jcopies]

                hj = gifi_transform(
                    data=gv['data'],
                    target=jtarget,
                    basis=gv['basis'],
                    copies=gv['copies'],
                    degree=gv['degree'],
                    ordinal=gv['ordinal'],
                    ties=gv['ties'],
                    missing=gv['missing'],
                )
                hj = gs_rc(normalize(center(hj)))[
                    'q']       # normalize transform

                # (nobs, ndim) scores
                sc = hj @ ja

                # Update mutable state
                xGifi[i][j]['transform'] = hj
                xGifi[i][j]['weights'] = ja
                xGifi[i][j]['scores'] = sc
                xGifi[i][j]['quantifications'] = ls_rc(gv['basis'], sc)[
                    'solution']

                if gv['active']:
                    hh_new_parts.append(hj)

                scopies += jcopies

            if len(hh_new_parts) > 0:
                hh_new = np.hstack(hh_new_parts)
                ha = hh_new @ aa
                xz += ha
                fnew += np.sum((x - ha) ** 2)

        fmid /= (asets * ndim)
        fnew /= (asets * ndim)

        if verbose:
            print(
                f"Iter {
                    itel:4d}  fold={
                    fold:.8f}  fmid={
                    fmid:.8f}  fnew={
                    fnew:.8f}")

        # Convergence check (matches R: itel > 1 required)
        if (itel == itmax or (fold - fnew) < eps) and itel > 1:
            break

        itel += 1
        fold = fnew
        x = gs_rc(center(xz))['q']

    return {
        'f': fnew,
        'ntel': itel,
        'x': x,
        'xGifi': xGifi,
    }


def gifi_loss(X, Z, H, A):
    """
    Compute the Gifi loss (stress) for optimal scaling.

    Formula: stress = sum_j ||X - H_j Z_j A_j||^2

    Parameters
    ----------
    X : np.ndarray (n_samples, n_dimensions)
        Object scores.
    Z : list of np.ndarray
        Category quantifications for each variable.
    H : list of sparse matrices or np.ndarray
        Indicator matrices for each variable.
    A : list of np.ndarray
        Loadings for each variable.

    Returns
    -------
    float
        The total computed stress value.
    """
    X = np.asarray(X)
    stress = 0.0

    for Hj, Zj, Aj in zip(H, Z, A):
        # Calculate Hj @ Zj (works for both dense and scipy.sparse Hj)
        HZ = Hj @ Zj

        # Calculate HZ @ Aj
        HZA = HZ @ Aj

        # Add squared Frobenius norm of difference
        diff = X - HZA
        stress += np.sum(diff ** 2)

    return float(stress)


def gifi_als(X_init, H_list, A_list, max_iter=1000, tol=1e-6, ridge_penalty=1e-8, ordinal=None):
    """
    Alternating Least Squares (ALS) algorithm for optimal scaling.

    Parameters
    ----------
    X_init : np.ndarray (n_samples, n_dimensions)
        Initial object scores.
    H_list : list of sparse matrices or np.ndarray
        Indicator matrices for each variable.
    A_list : list of np.ndarray
        Loadings for each variable.
    max_iter : int
        Maximum number of iterations.
    tol : float
        Tolerance for convergence based on stress difference.
    ridge_penalty : float
        Regularization term added to H^T H to prevent singular matrix inversion.
    ordinal : list of bool or None
        If provided, must be same length as H_list. When True at position j,
        category quantifications Z_j are constrained to be monotone non-decreasing
        (via PAVA) after each update, enforcing ordinal scaling for that variable.

    Returns
    -------
    X : np.ndarray
        Optimized object scores.
    Z_list : list of np.ndarray
        Optimized category quantifications.
    stress_history : list of floats
        Stress loss tracking across iterations.
    """
    X = np.asarray(X_init).copy()
    n_vars = len(H_list)

    # Precompute H_j^T H_j + lambda I (for stability)
    HTH_inv = []
    for Hj in H_list:
        if hasattr(Hj, "toarray"):  # Check if it's scipy sparse
            dense_H = Hj.toarray()
            HTH = dense_H.T @ dense_H
        else:
            HTH = Hj.T @ Hj

        HTH = HTH.astype(float)

        # Add ridge penalty to prevent singular matrices
        HTH += ridge_penalty * np.eye(HTH.shape[0])
        HTH_inv.append(np.linalg.inv(HTH))

    Z_list = [None] * n_vars
    stress_history = []
    ordinal = ordinal if ordinal is not None else [False] * n_vars

    # 1. Initialize object scores (done above: X = X_init)

    for it in range(max_iter):

        # 2. Update category quantifications Z_j
        for j in range(n_vars):
            Hj = H_list[j]
            Aj = A_list[j]

            # H_j^T X A_j^T
            HT_X_AT = Hj.T @ X @ Aj.T

            # Z_j = (H_j^T H_j + lambda I)^-1 H_j^T X A_j^T
            Z_list[j] = HTH_inv[j] @ HT_X_AT

            # 2.5 Apply PAVA monotone constraint for ordinal variables
            if ordinal[j]:
                from pygifi.utils.isotone import monotone_regression
                n_cats = Z_list[j].shape[0]
                x_ord = np.arange(1, n_cats + 1, dtype=float)
                Z_list[j] = monotone_regression(Z_list[j], x_ord)

        # 3. Update object scores X
        X_new = np.zeros_like(X)
        for j in range(n_vars):
            X_new += H_list[j] @ Z_list[j] @ A_list[j]
        X = X_new / n_vars

        # 4. Normalize scores (Enforce X^T X = I using SVD Orthogonalization)
        from pygifi.utils.utilities import svd_orthogonalize
        X = svd_orthogonalize(X)

        # 5. Compute stress
        current_stress = gifi_loss(X, Z_list, H_list, A_list)
        stress_history.append(current_stress)

        # 6. Check convergence
        if it > 0:
            diff = stress_history[-2] - current_stress
            if diff < tol:
                break

    return X, Z_list, stress_history


def gifi_majorization(X_init, H_list, A_list, max_iter=1000, tol=1e-6,
                      ridge_penalty=1e-8, ordinal=None):
    """
    Majorization algorithm for optimal scaling.

    Replaces the simple ALS averaging step with a Guttman transform that
    is derived as the exact minimizer of a surrogate majorizing function.
    This guarantees stress is non-increasing at every iteration.

    Algorithm (SMACOF/Gifi-style majorization):
        1. Initialize X with SVD orthogonalization.
        2. Update Z_j via ALS (same as gifi_als).
        2.5 Apply PAVA monotone constraint if ordinal[j] = True.
        3. Guttman transform: X_new = (1/J) * sum_j (H_j @ Z_j @ A_j)
           This step is the exact closed-form minimizer of the majorizing
           surrogate, guaranteeing stress(X_new) <= stress(X_old).
        4. SVD-orthogonalize X_new to enforce X^T X = I.
        5. Compute stress.
        6. Emit RuntimeWarning if stress increased (numerical noise).
        7. Repeat until |stress_prev - stress_new| < tol.

    Parameters
    ----------
    X_init : np.ndarray (n_samples, n_dimensions)
        Initial object scores.
    H_list : list of sparse matrices or np.ndarray
        Indicator matrices for each variable.
    A_list : list of np.ndarray
        Loadings for each variable.
    max_iter : int
        Maximum number of iterations.
    tol : float
        Convergence tolerance on stress.
    ridge_penalty : float
        Ridge regularisation for Z_j inversion stability.
    ordinal : list of bool or None
        Per-variable flag; if True, PAVA is applied to Z_j after each update.

    Returns
    -------
    X : np.ndarray (n_samples, n_dimensions)
        Optimised, orthogonalised object scores.
    Z_list : list of np.ndarray
        Category quantifications per variable.
    stress_history : list of float
        Monotone non-increasing stress at each iteration.
    """
    import warnings
    from pygifi.utils.utilities import svd_orthogonalize

    X = svd_orthogonalize(np.asarray(X_init).copy())
    n_samples = X.shape[0]
    n_vars = len(H_list)
    ordinal = ordinal if ordinal is not None else [False] * n_vars

    # Precompute (H_j^T H_j + lambda I)^{-1} for each variable
    HTH_inv = []
    for Hj in H_list:
        HTH = (Hj.toarray() if hasattr(Hj, 'toarray') else Hj).T \
            @ (Hj.toarray() if hasattr(Hj, 'toarray') else Hj)
        HTH = HTH.astype(float) + ridge_penalty * np.eye(HTH.shape[0])
        HTH_inv.append(np.linalg.inv(HTH))

    Z_list = [None] * n_vars
    stress_history = []

    # 1. Stress at initialisation
    # (Z_list is uninitialised; compute after first Z update)

    for it in range(max_iter):

        # 1. JS normalise X at the start (centre + ||X||_F = sqrt(n_samples))
        X_c = X - X.mean(axis=0)
        frob = np.linalg.norm(X_c, 'fro')
        scale = np.sqrt(n_samples) / frob if frob > 1e-15 else 1.0
        X = X_c * scale

        # 2. Update Z_j via ALS on the normalised X
        for j in range(n_vars):
            Hj, Aj = H_list[j], A_list[j]
            Z_list[j] = HTH_inv[j] @ (Hj.T @ X @ Aj.T)

            # 2.5 Optional PAVA isotone constraint (ordinal variables)
            if ordinal[j]:
                from pygifi.utils.isotone import monotone_regression
                n_cats = Z_list[j].shape[0]
                Z_list[j] = monotone_regression(
                    Z_list[j],
                    np.arange(1, n_cats + 1, dtype=float)
                )

        # 3. Guttman transform: X_new = (1/J) * sum_j H_j Z_j A_j
        X_new = np.zeros_like(X)
        for j in range(n_vars):
            ZA = Z_list[j] @ A_list[j]
            contrib = H_list[j] @ ZA
            if hasattr(contrib, 'toarray'):
                contrib = contrib.toarray()
            X_new += contrib
        X_new /= n_vars

        # 4. JS normalise X_new: centre + set ||X||_F = sqrt(n_samples).
        # This rescales X to a fixed magnitude so that stress values are
        # comparable across iterations — measured on the same X that will be
        # used for the next Z update.
        X_c = X_new - X_new.mean(axis=0)
        frob = np.linalg.norm(X_c, 'fro')
        scale = np.sqrt(n_samples) / frob if frob > 1e-15 else 1.0
        X = X_c * scale

        # 5. Measure stress on the JS-normalised X
        current_stress = gifi_loss(X, Z_list, H_list, A_list)
        stress_history.append(current_stress)

        # 6. Convergence + descent warning
        if it > 0:
            delta = stress_history[-2] - current_stress
            if delta < -1e-8:
                warnings.warn(
                    f"Majorization: stress increased by {-delta:.2e} at "
                    f"iteration {it}. Possible numerical instability.",
                    RuntimeWarning,
                    stacklevel=2,
                )
            if abs(delta) < tol:
                break

    # SVD-orthogonalise once for clean output satisfying X^T X = I
    return svd_orthogonalize(X), Z_list, stress_history
