# mypy: ignore-errors
"""
pygifi.plot — Visualization utilities for Gifi method results.

Python port of Gifi/R/plot.homals.R, Gifi/R/plot.princals.R, Gifi/R/plot.morals.R
(Mair, De Leeuw, Groenen. GPL-3.0).

Functions
---------
plot_homals    : Plot object scores and category quantifications (homals result)
plot_princals  : Biplot of object scores and component loadings (princals result)
plot_morals    : Transformation and fitted-vs-residual plot (morals result)
"""

import numpy as np
import matplotlib.pyplot as plt


def plot_homals(result, dim=None, which='objectscores', ax=None, **kwargs):
    """
    Plot homals results: object scores and/or category quantifications.

    Python port of R's plot.homals().

    Parameters
    ----------
    result : dict or object with attributes
        Output from Homals.fit().
    dim : list of 2 ints, default=[0, 1]
        Indices of dimensions to plot on x and y axes.
    type : str, optional
        Type of plot. One of 'jointplot', 'objplot', 'biplot', 'screeplot', 'transplot'.
        Defaults to 'jointplot'.
    which : str or list, optional
        Deprecated mapping parameter. Kept for backwards compatibility.
    ax : matplotlib.axes.Axes, optional
        Axes to plot into. If None, a new figure is created.

    Returns
    -------
    matplotlib.axes.Axes
    """
    if dim is None:
        dim = [0, 1]
    if ax is None:
        fig, ax = plt.subplots(figsize=(7, 6))

    # Handle both dict and object-style results
    def get(r, k):
        return r[k] if isinstance(r, dict) else getattr(r, k)

    plot_type = kwargs.pop('type', 'jointplot')
    # Fallback to older `which` parameter
    if which != 'objectscores':
        plot_type = which

    if plot_type == 'screeplot':
        evals = np.asarray(get(result, 'evals'))
        ax.bar(np.arange(len(evals)) + 1, evals, color='steelblue', alpha=0.7)
        ax.set_xlabel('Dimension')
        ax.set_ylabel('Eigenvalue')
        ax.set_title('Homals — Scree Plot')
        ax.set_xticks(np.arange(len(evals)) + 1)
        return ax

    if plot_type == 'transplot':
        # Transformation plot groups by variable
        transforms = get(result, 'transform')
        data = get(result, 'data')
        var_colors = plt.cm.Set1(np.linspace(0, 1, len(transforms)))
        for j, tr in enumerate(transforms):
            # plot first copy of transform against original numeric values
            col_data = np.asarray(get(result, 'datanum')[:, j])
            sorted_idx = np.argsort(col_data)
            ax.step(
                col_data[sorted_idx],
                np.asarray(tr)[
                    sorted_idx,
                    0],
                where='mid',
                color=var_colors[j],
                label=data.columns[j] if hasattr(
                    data,
                    'columns') else f"Var{j}",
                alpha=0.8)

        ax.set_xlabel('Original Values (quantified)')
        ax.set_ylabel('Transformed Scale')
        ax.set_title('Homals — Transformation Plot')
        ax.legend()
        return ax

    which_list = ['objectscores', 'quantifications'] if plot_type == 'jointplot' else [
        'objectscores'] if plot_type == 'objplot' else ['objectscores', 'loadings']

    if 'objectscores' in which_list:
        scores = np.asarray(get(result, 'objectscores'))
        ax.scatter(scores[:, dim[0]], scores[:, dim[1]],
                   color='steelblue', alpha=0.4, s=8, zorder=2, **kwargs)

    if 'quantifications' in which_list:
        # list or dict of (n_cats, ndim) arrays
        quants = get(result, 'quantifications')
        data = get(result, 'data')                # original DataFrame
        var_colors = plt.cm.Set1(np.linspace(0, 1, len(quants)))

        # Normalize quantifications to an iterable of arrays
        quants_list = list(
            quants.values()) if isinstance(
            quants,
            dict) else quants

        for j, q in enumerate(quants_list):
            q = np.asarray(q)
            # Get category labels from the original data column
            col = data.iloc[:, j]
            if hasattr(col, 'cat'):
                cat_labels = col.cat.categories.tolist()
            else:
                cat_labels = sorted(col.unique())

            # Handle 1D quantifications (variables with <= ndim categories)
            if q.ndim == 1:
                q = q[:, None]
            if q.shape[1] <= dim[1]:
                # Pad with zeros for missing dimensions
                padded = np.zeros((q.shape[0], dim[1] + 1))
                padded[:, :q.shape[1]] = q
                q = padded

            n_cats = q.shape[0]
            for i in range(min(n_cats, len(cat_labels))):
                ax.scatter(q[i, dim[0]], q[i, dim[1]],
                           color=var_colors[j], marker='^', s=60,
                           edgecolors='black', linewidths=0.5, zorder=5)
                ax.annotate(str(cat_labels[i]),
                            xy=(q[i, dim[0]], q[i, dim[1]]),
                            xytext=(4, 4), textcoords='offset points',
                            fontsize=7, color=var_colors[j], fontweight='bold',
                            bbox=dict(facecolor='white', alpha=0.7,
                                      edgecolor='none', pad=0.3))

    if 'loadings' in which_list:
        try:
            loadings = np.asarray(get(result, 'loadings'))
            scores = np.asarray(get(result, 'objectscores'))
            scalef = np.percentile(np.abs(scores), 80) / \
                (np.max(np.abs(loadings)) + 1e-12)
            for i in range(loadings.shape[0]):
                ax.annotate('',
                            xy=(loadings[i,
                                         dim[0]] * scalef,
                                loadings[i,
                                         dim[1]] * scalef),
                            xytext=(0,
                                    0),
                            arrowprops=dict(arrowstyle='->',
                                            color='coral',
                                            lw=1.5))
        except Exception:
            pass

    ax.axhline(0, color='gray', linewidth=0.5, linestyle='--')
    ax.axvline(0, color='gray', linewidth=0.5, linestyle='--')
    ax.set_xlabel(f'Dimension {dim[0] + 1}')
    ax.set_ylabel(f'Dimension {dim[1] + 1}')
    ax.set_title('Homals — Object Scores & Quantifications')

    return ax


def plot_princals(result, dim=None, type='biplot', ax=None, **kwargs):
    """
    Plot princals results: biplot of object scores and loadings.

    Python port of R's plot.princals().

    Parameters
    ----------
    result : dict or object
        Output from Princals.fit().
    dim : list of 2 ints, default=[0, 1]
        Dimensions to plot.
    type : str
        'biplot' — overlay object scores and loadings.
        'scores' — only object scores.
        'loadings' — only component loadings (bar chart).
        'screeplot' — eigenvalue bar chart.
        'transplot' — original vs transformed data.
    ax : matplotlib.axes.Axes, optional

    Returns
    -------
    matplotlib.axes.Axes
    """
    if dim is None:
        dim = [0, 1]

    def get(r, k):
        return r[k] if isinstance(r, dict) else getattr(r, k)

    if type == 'screeplot':
        if ax is None:
            fig, ax = plt.subplots(figsize=(7, 5))
        evals = np.asarray(get(result, 'evals'))
        ax.bar(np.arange(len(evals)) + 1, evals, color='steelblue', alpha=0.7)
        ax.set_xlabel('Dimension')
        ax.set_ylabel('Eigenvalue')
        ax.set_title('Princals — Scree Plot')
        ax.set_xticks(np.arange(len(evals)) + 1)
        return ax

    if type == 'transplot':
        if ax is None:
            fig, ax = plt.subplots(figsize=(7, 6))
        transforms = get(result, 'transform')
        data = get(result, 'data')

        # If transform is a list of matrices, handle it. If it's a single
        # matrix, split by columns.
        if isinstance(transforms, np.ndarray):
            transforms = [transforms[:, i:i + 1]
                          for i in range(transforms.shape[1])]

        var_colors = plt.cm.Set1(np.linspace(0, 1, len(transforms)))
        for j, tr in enumerate(transforms):
            col_data = np.asarray(get(result, 'datanum')[:, j])
            sorted_idx = np.argsort(col_data)
            ax.step(
                col_data[sorted_idx],
                np.asarray(tr)[
                    sorted_idx,
                    0],
                where='mid',
                color=var_colors[j],
                label=data.columns[j] if hasattr(
                    data,
                    'columns') else f"Var{j}",
                alpha=0.8)

        ax.set_xlabel('Original Values (quantified)')
        ax.set_ylabel('Transformed Scale')
        ax.set_title('Princals — Transformation Plot')
        ax.legend()
        return ax

    if type == 'loadings':
        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 5))
        loadings = np.asarray(get(result, 'loadings'))
        n_vars = loadings.shape[0] if loadings.ndim > 1 else 1
        x_pos = np.arange(n_vars)
        ax.bar(x_pos, loadings[:, dim[0]] if loadings.ndim > 1 else loadings,
               color='steelblue', alpha=0.7, label=f'Dim {dim[0] + 1}')
        if loadings.ndim > 1 and loadings.shape[1] > 1:
            ax.bar(x_pos, loadings[:, dim[1]], color='coral', alpha=0.7,
                   label=f'Dim {dim[1] + 1}')
        ax.set_title('Princals — Component Loadings')
        ax.legend()
    else:
        if ax is None:
            fig, ax = plt.subplots(figsize=(7, 6))
        scores = np.asarray(get(result, 'objectscores'))
        ax.scatter(scores[:,
                          dim[0]],
                   scores[:,
                   dim[1]],
                   color='steelblue',
                   alpha=0.6,
                   zorder=3,
                   label='Objects',
                   **kwargs)

        if type == 'biplot':
            try:
                loadings = np.asarray(get(result, 'loadings'))
                scalef = np.percentile(np.abs(scores),
                                       80) / (np.max(np.abs(loadings)) + 1e-12)
                for i in range(loadings.shape[0]):
                    ax.annotate('',
                                xy=(loadings[i,
                                             dim[0]] * scalef,
                                    loadings[i,
                                             dim[1]] * scalef),
                                xytext=(0,
                                        0),
                                arrowprops=dict(arrowstyle='->',
                                                color='coral',
                                                lw=1.5))
            except Exception:
                pass  # Silently skip loadings overlay if not available

        ax.axhline(0, color='gray', linewidth=0.5, linestyle='--')
        ax.axvline(0, color='gray', linewidth=0.5, linestyle='--')
        ax.set_xlabel(f'Dimension {dim[0] + 1}')
        ax.set_ylabel(f'Dimension {dim[1] + 1}')
        ax.set_title('Princals — Biplot')

    return ax


def plot_morals(result, ncols=2):
    """Mirrors R's plot.morals: observed vs transformed per variable."""
    def get(r, k):
        return r[k] if isinstance(r, dict) else getattr(r, k)

    # support both Morals object and dict containing results
    data_X = get(
        result,
        'X_') if hasattr(
        result,
        'X_') else (
            result.get('data') if isinstance(
                result,
                dict) else getattr(
                    result,
                    'data',
                None))
    if data_X is None or not hasattr(data_X, 'columns'):
        # fallback if attributes not found
        num_preds = result.get('n_pred_') if isinstance(
            result, dict) else getattr(
            result, 'n_pred_', None)
        xhat_matrix = result.get('xhat') if isinstance(
            result, dict) else getattr(
            result, 'xhat', getattr(
                result, 'result_', {}).get(
                'xhat', np.empty(
                    (0, 1))))
        num_preds = num_preds or (
            xhat_matrix.shape[1] if xhat_matrix is not None else 1)
        cols = [f"X{i}" for i in range(num_preds)]
        X_obs = np.asarray(data_X) if data_X is not None else np.zeros(
            (xhat_matrix.shape[0], len(cols)))
    else:
        cols = list(data_X.columns)
        X_obs = data_X.values

    y_obs = result.get('y_') if isinstance(
        result, dict) else getattr(
        result, 'y_', None)
    if y_obs is None:
        y_obs = np.zeros(len(X_obs))

    xhat = getattr(
        result,
        'result_',
        {}).get('xhat') if hasattr(
        result,
        'result_') else (
            result.get('xhat') if isinstance(
                result,
                dict) else getattr(
                    result,
                    'xhat',
                    np.empty(
                        (0,
                         1))))
    yhat = getattr(
        result,
        'result_',
        {}).get('yhat') if hasattr(
        result,
        'result_') else (
            result.get('yhat') if isinstance(
                result,
                dict) else getattr(
                    result,
                    'yhat',
                    np.zeros(
                        len(X_obs))))

    nplots = len(cols) + 1   # predictors + response
    nrows = int(np.ceil(nplots / ncols))

    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows))
    axes = np.atleast_1d(axes).flatten()

    # predictor transformations
    for i, col in enumerate(cols):
        x_obs_i = X_obs[:, i]
        x_hat_i = xhat[:, i]   # transformed predictor i
        order = np.argsort(x_obs_i)
        axes[i].plot(x_obs_i[order], x_hat_i[order], 'k-')
        axes[i].set_xlabel('Observed')
        axes[i].set_ylabel('Transformed')
        axes[i].set_title(col)

    # response transformation
    y_obs_arr = np.asarray(y_obs)
    order = np.argsort(y_obs_arr)
    axes[len(cols)].plot(y_obs_arr[order], yhat[order], 'k-')
    axes[len(cols)].set_xlabel('Observed')
    axes[len(cols)].set_ylabel('Transformed')

    y_name = 'Response'
    if hasattr(y_obs, 'name') and y_obs.name:
        y_name = str(y_obs.name)
    axes[len(cols)].set_title(y_name)

    # hide unused panels
    for j in range(nplots, len(axes)):
        axes[j].set_visible(False)

    fig.suptitle('MORALS', fontweight='bold')
    plt.tight_layout()
    return fig


def plot_object_scores(model, dim=None, ax=None, **kwargs):
    """
    Generic 2D scatter plot of object scores for any fitted Gifi model.

    Parameters
    ----------
    model : fitted Gifi estimator (Princals, Homals, or Morals)
    dim : list of 2 ints, default=[0, 1]
    ax : matplotlib.axes.Axes, optional
        Axes to plot into. Creates new figure if None.
    **kwargs : additional keyword arguments passed to ax.scatter()
    """
    if dim is None:
        dim = [0, 1]
    if ax is None:
        fig, ax = plt.subplots(figsize=(7, 6))

    scores = model.object_scores_
    if scores is None:
        raise ValueError("Model does not have 'object_scores_'. Ensure it is fitted.")

    # Only plot if we have enough dimensions
    if scores.shape[1] <= dim[1]:
        raise ValueError(f"Dim {dim} out of bounds for {scores.shape[1]}D object scores.")

    kwargs.setdefault('color', 'steelblue')
    kwargs.setdefault('alpha', 0.6)
    kwargs.setdefault('s', 20)
    kwargs.setdefault('zorder', 3)

    ax.scatter(scores[:, dim[0]], scores[:, dim[1]], label='Objects', **kwargs)

    ax.axhline(0, color='gray', linewidth=0.5, linestyle='--')
    ax.axvline(0, color='gray', linewidth=0.5, linestyle='--')
    ax.set_xlabel(f'Dimension {dim[0] + 1}')
    ax.set_ylabel(f'Dimension {dim[1] + 1}')
    ax.set_title(f'{model.__class__.__name__} — Object Scores')

    return ax


def plot_quantifications(model, dim=None, ax=None, **kwargs):
    """
    Generic 2D scatter plot of category quantifications.

    Parameters
    ----------
    model : fitted Gifi estimator (Princals, Homals)
    dim : list of 2 ints, default=[0, 1]
    ax : matplotlib.axes.Axes, optional
    **kwargs : additional arguments
    """
    if dim is None:
        dim = [0, 1]
    if ax is None:
        fig, ax = plt.subplots(figsize=(7, 6))

    quants = model.category_quantifications_
    if quants is None:
        raise ValueError(
            "Model does not have 'category_quantifications_'. (Note: Morals doesn't compute standard quantifications).")

    # Handle dictionary (Homals) or list (Princals)
    if isinstance(quants, dict):
        q_list = list(quants.values())
        names = list(quants.keys())
    else:
        q_list = quants
        names = [f"Var{j}" for j in range(len(q_list))]

    var_colors = plt.cm.Set1(np.linspace(0, 1, len(q_list)))

    # Try to grab original variables to get category labels
    data = None
    if hasattr(model, 'result_') and 'data' in model.result_:
        data = model.result_['data']

    for j, (name, q) in enumerate(zip(names, q_list)):
        q = np.asarray(q)
        if q.ndim == 1:
            q = q[:, None]

        if q.shape[1] <= dim[1]:
            padded = np.zeros((q.shape[0], dim[1] + 1))
            padded[:, :q.shape[1]] = q
            q = padded

        n_cats = q.shape[0]
        cat_labels = list(range(n_cats))

        if data is not None and j < len(data.columns):
            col = data.iloc[:, j]
            if hasattr(col, 'cat'):
                cat_labels = col.cat.categories.tolist()
            else:
                cat_labels = sorted(col.unique())

        for i in range(min(n_cats, len(cat_labels))):
            ax.scatter(q[i, dim[0]], q[i, dim[1]],
                       color=var_colors[j], marker='^', s=60,
                       edgecolors='black', linewidths=0.5, zorder=5)
            ax.annotate(str(cat_labels[i]),
                        xy=(q[i, dim[0]], q[i, dim[1]]),
                        xytext=(4, 4), textcoords='offset points',
                        fontsize=7, color=var_colors[j], fontweight='bold')

    ax.axhline(0, color='gray', linewidth=0.5, linestyle='--')
    ax.axvline(0, color='gray', linewidth=0.5, linestyle='--')
    ax.set_xlabel(f'Dimension {dim[0] + 1}')
    ax.set_ylabel(f'Dimension {dim[1] + 1}')
    ax.set_title(f'{model.__class__.__name__} — Category Quantifications')

    return ax


def plot_biplot(model, dim=None, ax=None, **kwargs):
    """
    Generic 2D biplot of object scores and component loadings.

    Parameters
    ----------
    model : fitted Gifi estimator (Princals, Homals)
    dim : list of 2 ints, default=[0, 1]
    ax : matplotlib.axes.Axes, optional
    """
    if dim is None:
        dim = [0, 1]
    if ax is None:
        fig, ax = plt.subplots(figsize=(7, 6))

    # Plot scores first
    plot_object_scores(model, dim=dim, ax=ax, **kwargs)

    loadings = model.component_loadings_
    scores = model.object_scores_

    if loadings is None or scores is None:
        return ax

    if isinstance(loadings, dict):
        loadings_arr = np.vstack(list(loadings.values()))  # stack dict values (e.g., from Homals)
    else:
        loadings_arr = np.asarray(loadings)

    # Check if we have 2 dimensions to plot arrows
    if loadings_arr.ndim > 1 and loadings_arr.shape[1] > dim[1]:
        # Scale arrows to fit nicely within objects
        scalef = np.percentile(np.abs(scores), 80) / (np.max(np.abs(loadings_arr)) + 1e-12)

        for i in range(loadings_arr.shape[0]):
            ax.annotate('',
                        xy=(loadings_arr[i, dim[0]] * scalef,
                            loadings_arr[i, dim[1]] * scalef),
                        xytext=(0, 0),
                        arrowprops=dict(arrowstyle='->', color='coral', lw=1.5))

    ax.set_title(f'{model.__class__.__name__} — Biplot')
    return ax
