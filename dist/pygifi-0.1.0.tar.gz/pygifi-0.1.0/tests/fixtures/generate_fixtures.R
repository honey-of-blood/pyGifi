# tests/fixtures/generate_fixtures.R
# R script to generate ground-truth output from cran/Gifi

library(Gifi)
library(jsonlite)

# 1. Homals Default (Hartigan)
data(hartigan)
write.csv(hartigan, "tests/fixtures/hartigan.csv", row.names=FALSE)
h_fit <- homals(hartigan, ndim = 2)

write_json(list(
  objectscores = h_fit$objectscores,
  evals = h_fit$evals,
  quantifications = h_fit$quantifications,
  f = h_fit$f,
  ntel = h_fit$ntel
), "tests/fixtures/homals_hartigan.json", digits = 10, null="null", auto_unbox=TRUE)

# 2. Princals Default (ABC)
data(ABC)
write.csv(ABC, "tests/fixtures/ABC.csv", row.names=FALSE)
# Convert ABC numeric to factors for princals ordinal
abc_ord <- as.data.frame(lapply(ABC, as.factor))
p_fit <- princals(abc_ord, ndim = 2)

write_json(list(
  objectscores = p_fit$objectscores,
  evals = p_fit$evals,
  quantifications = p_fit$quantifications,
  loadings = p_fit$loadings,
  f = p_fit$f
), "tests/fixtures/princals_abc.json", digits = 10, null="null", auto_unbox=TRUE)

# 3. Morals Default (Neumann)
data(neumann)
write.csv(neumann, "tests/fixtures/neumann.csv", row.names=FALSE)
# neumann[,1:2] as X, neumann[,3] as y
m_fit <- morals(neumann[,1:2], neumann[,3])

write_json(list(
  evals = m_fit$evals,
  smc = m_fit$smc,
  yhat = m_fit$yhat,
  ypred = m_fit$ypred,
  xhat = m_fit$xhat
), "tests/fixtures/morals_neumann.json", digits = 10, null="null", auto_unbox=TRUE)

cat("Successfully generated R Gifi fixtures and datasets in tests/fixtures/\n")
