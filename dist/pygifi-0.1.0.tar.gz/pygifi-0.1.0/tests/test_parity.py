import os
import sys

# Adjust if PyGifi path is external
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import json  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from pygifi import Homals, Princals, Morals  # noqa: E402

FIXTURE_DIR = os.path.join(os.path.dirname(__file__), 'fixtures')


def load_fixture(filename):
    with open(os.path.join(FIXTURE_DIR, filename), 'r') as f:
        return json.load(f)


def test_homals_r_parity():
    # 1. Load data
    df = pd.read_csv(os.path.join(FIXTURE_DIR, 'hartigan.csv'))
    ref = load_fixture('homals_hartigan.json')

    # 2. Fit model (Strict tol to match R)
    model = Homals(ndim=2, optimizer="majorization", eps=1e-8, itmax=1000).fit(df)

    # 3. Compare eigenvalues
    r_evals = np.array(ref['evals'])
    py_evals = np.array(model.eigenvalues_)
    print("Homals Eigenvalues -> R:", r_evals, "Python:", py_evals)
    assert np.allclose(py_evals, r_evals, atol=1e-2), "Homals Eigenvalues do not match R"
    # 4. Compare stress
    r_stress = ref['f']
    py_stress = model.result_['f']
    print("Homals Stress -> R:", r_stress, "Python:", py_stress)
    assert np.allclose(py_stress, r_stress, atol=1e-2), "Homals Stress does not match R"
    # 5. Coordinate invariants (Object scores/loadings subject to orthogonal rotation differences in LAPACK)
    # Testing eigenvalues and stress ensures the underlying manifold and optimization convergence is identical.
    pass


def test_princals_r_parity():
    # 1. Load data
    df = pd.read_csv(os.path.join(FIXTURE_DIR, 'ABC.csv'))
    ref = load_fixture('princals_abc.json')

    # 2. Fit model (ABC defaults to all nominal in Homals, but Gifi Princals defaults to all ordinal)
    # We must match the R ord=["TRUE", "TRUE", "TRUE"] default
    model = Princals(ndim=2, ordinal=True, optimizer="majorization", eps=1e-8, itmax=1000).fit(df)

    # 3. Compare eigenvalues
    r_evals = np.array(ref['evals'])
    py_evals = np.array(model.eigenvalues_)
    print("Princals Eigenvalues -> R:", r_evals, "Python:", py_evals)
    assert np.allclose(py_evals, r_evals, atol=1e-2), "Princals Eigenvalues do not match R"

    # 4. Compare stress
    r_stress = ref['f']
    py_stress = model.result_['f']
    print("Princals Stress -> R:", r_stress, "Python:", py_stress)
    assert np.allclose(py_stress, r_stress, atol=1e-2), "Princals Stress do not match R"

    # 5. Coordinate invariants (Object scores/loadings subject to orthogonal rotation differences in LAPACK)
    # Testing eigenvalues and stress ensures the underlying manifold and optimization convergence is identical.
    pass


def test_morals_r_parity():
    # 1. Load data
    df = pd.read_csv(os.path.join(FIXTURE_DIR, 'neumann.csv'))
    ref = load_fixture('morals_neumann.json')

    X = df.iloc[:, 0:2]
    y = df.iloc[:, 2]

    # 2. Fit model
    model = Morals(eps=1e-8, itmax=1000).fit(X, y)

    # 3. Compare eigenvalues
    r_evals = np.array(ref['evals'])
    py_evals = np.array(model.eigenvalues_)
    print("Morals Eigenvalues -> R:", r_evals, "Python:", py_evals)
    # R's morals does not export evals (it exports None). We compute it explicitly in Pygifi.
    # Therefore, we skip eigenvalue parity check for Morals.

    # 4. Compare smc (stress equivalent)
    r_smc = ref['smc'][0] if isinstance(ref['smc'], list) else ref['smc']
    py_smc = model.result_['smc']
    print("Morals SMC -> R:", r_smc, "Python:", py_smc)
    assert np.allclose(py_smc, r_smc, atol=1e-2), f"Morals SMC does not match R: {py_smc} != {r_smc}"


if __name__ == "__main__":
    print("Running Homals parity test...")
    try:
        test_homals_r_parity()
        print("Homals passed!")
    except Exception as e:
        print(f"Homals failed: {e}")

    print("\nRunning Princals parity test...")
    try:
        test_princals_r_parity()
        print("Princals passed!")
    except Exception as e:
        print(f"Princals failed: {e}")

    print("\nRunning Morals parity test...")
    try:
        test_morals_r_parity()
        print("Morals passed!")
    except Exception as e:
        print(f"Morals failed: {e}")
